package com.projetointegrador.bateaqui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.navigation.fragment.findNavController




class CalendarioFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_calendario, container, false)


        // botão Início
        setupBotaoInicio(view)

        // botão relatorio
        setupBotaoRelatorio(view)

        return view
    }

    private fun setupBotaoInicio(view: View) {
        val botaoInicio = view.findViewById<Button>(R.id.botao_inicio)
        botaoInicio.setOnClickListener {
            findNavController().navigate(R.id.action_calendarioFragment2_to_inicioGeralFragment)
        }
    }

    private fun setupBotaoRelatorio(view: View) {
        val botaoRelatorio = view.findViewById<Button>(R.id.botao_relatorio)
        botaoRelatorio.setOnClickListener {
            findNavController().navigate(R.id.action_calendarioFragment2_to_relatorioFragment)
        }
    }

}
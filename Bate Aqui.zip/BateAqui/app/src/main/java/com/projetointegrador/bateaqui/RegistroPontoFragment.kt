package com.projetointegrador.bateaqui

import android.Manifest
import android.content.ContentValues.TAG
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnSuccessListener
import androidx.annotation.NonNull
import androidx.navigation.fragment.findNavController
import com.projetointegrador.bateaqui.auth.util.FirebaseAuthUtil
import com.projetointegrador.bateaqui.database.FirestoreUtil
import com.projetointegrador.bateaqui.database.UserPonto
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.location.Location

class RegistroPontoFragment : Fragment() {

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private val LOCATION_PERMISSION_REQUEST_CODE = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_registro_ponto, container, false)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireActivity())

        // Solicitar permissão de localização, se não for concedida
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestLocationPermission()
        } else {
            getCoordinates()
        }

        // Configurações dos botões
        setupBotaoInicio(view)
        setupBotaoRegistrarPonto(view)
        setupHorarioAtual(view)
        setupBotaoRelatorio(view)

        return view
    }

    private fun requestLocationPermission() {
        requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        @NonNull permissions: Array<out String>,
        @NonNull grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCoordinates()
            } else {
                Toast.makeText(requireContext(), "Permissão de localização negada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Função para verificar se a localização está dentro da área permitida
    private fun isWithinAllowedArea(latitude: Double, longitude: Double): Boolean {
        // Coordenadas do centro da área permitida (substitua pelas coordenadas corretas)
        val centerLatitude = -22.834575
        val centerLongitude = -47.049426


        // Raio em metros (10 km ou outra distância)
        val allowedRadius = 1000.0  // 10 km

        // Calcular a distância entre a localização atual e o centro permitido
        val results = FloatArray(1)
        Location.distanceBetween(
            latitude,
            longitude,
            centerLatitude,
            centerLongitude,
            results
        )

        val distance = results[0]
        Log.d("RegistroPontoFragment", "Distância calculada: $distance metros")  // Debug para verificar a distância

        // Retornar se a distância está dentro do raio permitido
        return distance <= allowedRadius
    }

    private fun getCoordinates() {
        // Verificar se as permissões de localização estão concedidas
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestLocationPermission()
            return
        }

        // Obter a última localização
        fusedLocationProviderClient.getLastLocation()
            .addOnSuccessListener { location ->
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude

                    if (isWithinAllowedArea(latitude, longitude)) {
                        // Latitude e longitude são válidas
                        Toast.makeText(requireContext(), "Latitude: $latitude, Longitude: $longitude", Toast.LENGTH_LONG).show()
                    } else {
                        // Localização fora da área permitida
                        Toast.makeText(requireContext(), "Fora da área permitida", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Localização indisponível", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun setupBotaoRegistrarPonto(view: View) {
        val botaoRegistrarPonto = view.findViewById<Button>(R.id.botao_registro_ponto)
        botaoRegistrarPonto.setOnClickListener {
            // Verificar se as permissões de localização estão concedidas
            if (ActivityCompat.checkSelfPermission(
                    requireContext(),  // Correção do contexto para fragment
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestLocationPermission()  // Solicitar permissão, se necessário
                return@setOnClickListener
            }

            // Se a permissão estiver concedida, obter a última localização
            fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener { location ->
                    if (location != null) {
                        val latitude = location.latitude
                        val longitude = location.longitude

                        // Verificar se está dentro da área permitida
                        if (isWithinAllowedArea(latitude, longitude)) {
                            // Está dentro do limite permitido, permitir o registro do ponto
                            // Seu código para registrar o ponto
                            val currentUserData = FirebaseAuthUtil.getCurrentUserData()
                            if (currentUserData != null) {
                                val userPonto = UserPonto(
                                    name = currentUserData.displayName ?: "Sem nome",
                                    email = currentUserData.email ?: "Sem email",
                                    identifier = currentUserData.uid ?: "Sem UID",
                                    dateHour = Calendar.getInstance().time
                                )

                                FirestoreUtil.addPonto(
                                    userPonto,
                                    onSuccess = { documentId ->
                                        Log.d("RegistroPontoFragment", "Ponto registrado com sucesso! Document ID: $documentId")
                                        Toast.makeText(
                                            requireContext(),
                                            "Ponto registrado com sucesso!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    onFailure = { e ->
                                        Log.e("RegistroPontoFragment", "Erro ao registrar ponto", e)
                                        Toast.makeText(
                                            requireContext(),
                                            "Erro ao registrar ponto",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                )
                            } else {
                                Toast.makeText(
                                    requireContext(),
                                    "Usuário não autenticado",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            // Se estiver fora da área permitida
                            Toast.makeText(
                                requireContext(),
                                "Fora da área permitida",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Localização indisponível",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
    }

    private fun setupBotaoInicio(view: View) {
        val botaoInicio = view.findViewById<Button>(R.id.botao_inicio)
        botaoInicio.setOnClickListener {
            findNavController().navigate(R.id.action_registrarPontoFragment_to_inicioGeralFragment)
        }
    }

    private fun setupHorarioAtual(view: View) {
        val textViewHoraDia = view.findViewById<TextView>(R.id.textViewHoraDia)
        val currentTime = Calendar.getInstance().time
        val dateFormat = SimpleDateFormat("EEEE HH:mm:ss", Locale.getDefault())
        val formattedTime = dateFormat.format(currentTime)

        textViewHoraDia.text = formattedTime
    }

    private fun setupBotaoRelatorio(view: View) {
        val botaoRelatorio = view.findViewById<Button>(R.id.botao_relatorio)
        botaoRelatorio.setOnClickListener {
            findNavController().navigate(R.id.action_registrarPontoFragment_to_relatorioFragment)
        }
    }
}
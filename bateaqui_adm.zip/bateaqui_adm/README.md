# Aplicativo de Gerenciamento de Pontos - Gestor

### Objetivo Principal
Oferecer uma visão geral e facilitada do registro de ponto para gestores, permitindo o gerenciamento dos horários trabalhados e a visualização de relatórios de frequência.

### Tecnologias:
Desenvolvimento de aplicativo móvel Multiplataforma com Flutter.
Utilização de Firebase para autenticação e armazenamento de dados.
